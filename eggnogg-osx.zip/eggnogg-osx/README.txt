EGGNOGG ...a parody of NIDHOGG...
by Paul and Connor Pridham (Copyright Madgarden 2013)

Made for TOJam 8 in May 2013.

CONTROLS:

Two players can play on the same keyboard, or using joysticks:

Player1 - Joystick 1, or keyboard
	- Move/aim: WASD
	- Attack: LCTRL or B
	- Run/Jump: LSHIFT or SPACE or V

Player2 - Joystick 1, or keyboard
	- Move/aim: CURSORS
	- Attack: RCTRL or NUM_ENTER or PERIOD
	- Run/jump: RSHIFT or NUM_PERIOD or COMMA

MOVES:

Aim the sword for blocking, stabbing, and throwing using UP/DOWN
controls. If an opponent's attack comes in low, middle, or high, you
can move your sword to block at the same height. This also works for
bare-fisted combat (though not against swords!) The player
will punch when in close, or otherwise kick (for more damage).

To RUN, press the RUN button and a direction left or right. Then while
running, press the RUN button again to jump. You can duck by pressing
RUN and down, and do a slide if you duck while you're running. You will
pick up a sword if you are empty-handed and duck near one.

Also while running, hold the ATTACK button to throw your sword. You
can throw it at various different angles, bounce it off of stuff. It
might even bounce back and impale you. Good times.

EXTRA INFO:

At the title screen, you can change your hero's colours by clicking the
P1/P2 buttons. You can also change your opponent's colours by pressing
certain keys or buttons. HEH HEH HEH.

You can change the window size using F1. Toggle fullscreen with F11.
Pressing F5 will restart a game immediately.

Check out @madgarden on Twitter, on our website at
http://www.madgarden.net, or email at info@madgarden.net

Good stabbing... seeya!
